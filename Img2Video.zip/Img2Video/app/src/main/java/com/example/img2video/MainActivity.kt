package com.example.img2video

import android.content.ContentValues
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import java.io.File

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private var imageUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private lateinit var video: VideoView
    private lateinit var durationBar: SeekBar
    private lateinit var durationLabel: TextView
    private lateinit var zoomCheck: CheckBox
    private lateinit var convertBtn: Button

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            imageUri = uri
            preview.setImageURI(uri)
            convertBtn.isEnabled = true
            status.text = "تم اختيار الصورة"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val pickBtn = Button(this).apply { text = "اختر صورة" }
        preview = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 600)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        durationLabel = TextView(this).apply { text = "المدة: 5 ثوانٍ" }
        durationBar = SeekBar(this).apply { max = 14; progress = 4 } // 1..15 ثانية
        durationBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                durationLabel.text = "المدة: ${p + 1} ثوانٍ"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        zoomCheck = CheckBox(this).apply { text = "تأثير تكبير تدريجي"; isChecked = true }
        convertBtn = Button(this).apply { text = "حوّل إلى فيديو"; isEnabled = false }
        status = TextView(this)
        video = VideoView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 700) }

        listOf(pickBtn, preview, durationLabel, durationBar, zoomCheck, convertBtn, status, video)
            .forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })

        pickBtn.setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        convertBtn.setOnClickListener { convert() }
    }

    private fun convert() {
        val uri = imageUri ?: return
        val seconds = durationBar.progress + 1
        val durationUs = seconds * 1_000_000L

        val effects = mutableListOf<Effect>(
            Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        )
        if (zoomCheck.isChecked) {
            effects.add(MatrixTransformation { t ->
                val s = 1f + 0.25f * (t.toFloat() / durationUs).coerceIn(0f, 1f)
                Matrix().apply { postScale(s, s) }
            })
        }

        val mediaItem = MediaItem.Builder().setUri(uri).setImageDurationMs(seconds * 1000L).build()
        val edited = EditedMediaItem.Builder(mediaItem)
            .setFrameRate(30)
            .setEffects(Effects(emptyList(), effects))
            .build()

        val out = File(cacheDir, "out_${System.currentTimeMillis()}.mp4")
        convertBtn.isEnabled = false
        status.text = "جارٍ التحويل..."

        val transformer = Transformer.Builder(this)
            .setVideoMimeType("video/avc")
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    saveToGallery(out)
                    runOnUiThread {
                        status.text = "تم الحفظ في المعرض (Movies/Img2Video)"
                        convertBtn.isEnabled = true
                        video.setVideoURI(Uri.fromFile(out))
                        video.setMediaController(MediaController(this@MainActivity))
                        video.start()
                    }
                }
                override fun onError(composition: Composition, result: ExportResult, e: ExportException) {
                    runOnUiThread {
                        status.text = "فشل التحويل: ${e.message}"
                        convertBtn.isEnabled = true
                    }
                }
            })
            .build()
        transformer.start(edited, out.absolutePath)
    }

    private fun saveToGallery(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Img2Video")
            }
        }
        val dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return
        contentResolver.openOutputStream(dest)?.use { o -> file.inputStream().use { it.copyTo(o) } }
    }
}
